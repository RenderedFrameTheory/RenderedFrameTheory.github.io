"""
RFT Core Functions - Enhanced mathematical operations for Rendered Frame Theory
"""

import math
import logging

logger = logging.getLogger(__name__)

# RFT Configuration
RFT_CORE_VERSION = "Ω-1.0"
ENABLE_LOGGING = True

def delta_phi(freq_a, freq_b):
    """Calculate phase differential between two frequencies"""
    return abs(freq_a - freq_b)

def render_delay(z):
    """Calculate render delay based on complexity factor z"""
    return 1.38 * math.log(1 + z)

def v_sight(flicker_rate, tau_eff):
    """Calculate sight velocity based on flicker rate and effective timing"""
    if tau_eff == 0:
        return 0
    return flicker_rate / tau_eff

def chrono_refract(t, n_chrono):
    """Calculate chronological refraction"""
    return t * n_chrono

def coherence_omega_obs(temp, humidity, wind_speed):
    """
    Calculate coherence observer state (Ω_obs) from atmospheric parameters
    Enhanced formula for weather-based RFT analysis
    """
    try:
        # Normalize temperature to 0-1 range (assuming -40 to 50°C range)
        temp_norm = max(0, min(1, (temp + 40) / 90))
        
        # Normalize humidity (0-100%)
        humidity_norm = humidity / 100
        
        # Normalize wind speed (assuming 0-50 m/s range)
        wind_norm = min(1, wind_speed / 50)
        
        # Enhanced coherence calculation with atmospheric dynamics
        coherence = (temp_norm * 0.4 + humidity_norm * 0.35 + wind_norm * 0.25)
        
        # Apply atmospheric pressure influence (simplified)
        atmospheric_factor = 1 + (0.1 * math.sin(temp_norm * math.pi))
        
        omega_obs = round(coherence * atmospheric_factor, 4)
        
        if ENABLE_LOGGING:
            logger.debug(f"Coherence calculated: temp={temp}, humidity={humidity}, wind={wind_speed} -> Ω_obs={omega_obs}")
        
        return omega_obs
        
    except Exception as e:
        logger.error(f"Error calculating coherence: {str(e)}")
        return 0.5  # Default stable value

def predict_rft_state(omega):
    """
    Predict RFT state based on omega coherence value
    Enhanced classification with more nuanced states
    """
    try:
        if omega < 0.3:
            return "Low_Coherence"
        elif omega < 0.6:
            return "Stable"
        elif omega < 0.8:
            return "Elevated"
        elif omega < 1.0:
            return "Transitional"
        elif omega < 1.3:
            return "Dynamic"
        else:
            return "Volatile"
            
    except Exception as e:
        logger.error(f"Error predicting RFT state: {str(e)}")
        return "Unknown"

def calculate_atmospheric_tau_eff(pressure, temp, humidity):
    """
    Calculate effective timing (τ_eff) based on atmospheric conditions
    """
    try:
        # Normalize atmospheric pressure (standard 1013.25 hPa)
        pressure_factor = pressure / 1013.25
        
        # Temperature influence on timing
        temp_factor = 1 + ((temp - 20) / 100)  # Reference 20°C
        
        # Humidity influence
        humidity_factor = 1 + ((humidity - 50) / 200)  # Reference 50%
        
        tau_eff = pressure_factor * temp_factor * humidity_factor
        
        return round(tau_eff, 4)
        
    except Exception as e:
        logger.error(f"Error calculating atmospheric tau_eff: {str(e)}")
        return 1.0

def atmospheric_delta_phi(temp, pressure, reference_temp=20, reference_pressure=1013.25):
    """
    Calculate atmospheric phase differential
    """
    try:
        temp_delta = abs(temp - reference_temp) / 50  # Normalize
        pressure_delta = abs(pressure - reference_pressure) / 100  # Normalize
        
        delta_phi_val = math.sqrt(temp_delta**2 + pressure_delta**2)
        
        return round(delta_phi_val, 4)
        
    except Exception as e:
        logger.error(f"Error calculating atmospheric delta_phi: {str(e)}")
        return 0.0

def rft_weather_analysis(temp, humidity, wind_speed, pressure):
    """
    Comprehensive RFT analysis of weather data
    """
    try:
        omega_obs = coherence_omega_obs(temp, humidity, wind_speed)
        tau_eff = calculate_atmospheric_tau_eff(pressure, temp, humidity)
        delta_phi_val = atmospheric_delta_phi(temp, pressure)
        state = predict_rft_state(omega_obs)
        
        # Calculate render factor
        render_factor = omega_obs / (delta_phi_val + 0.001)  # Avoid division by zero
        
        analysis = {
            'omega_obs': omega_obs,
            'tau_eff': tau_eff,
            'delta_phi': delta_phi_val,
            'state': state,
            'render_factor': round(render_factor, 4),
            'coherence_level': _classify_coherence(omega_obs)
        }
        
        return analysis
        
    except Exception as e:
        logger.error(f"Error in RFT weather analysis: {str(e)}")
        return None

def _classify_coherence(omega_obs):
    """Classify coherence level for interpretation"""
    if omega_obs < 0.4:
        return "LOW"
    elif omega_obs < 0.7:
        return "MODERATE"
    elif omega_obs < 1.0:
        return "HIGH"
    else:
        return "EXTREME"

def analyze_magnetic_data(Bx, By, Bz):
    """
    Analyze magnetic field data and calculate RFT parameters
    
    Args:
        Bx, By, Bz: Magnetic field components in μT
        
    Returns:
        Formatted magnetic field analysis string
    """
    try:
        # Calculate vector magnitude
        magnitude = (Bx**2 + By**2 + Bz**2)**0.5
        
        # Normalize to simulation threshold (50 μT reference)
        omega_obs = round(magnitude / 50.0, 4)
        
        # Get RFT state prediction
        state = predict_rft_state(omega_obs)
        
        # Calculate additional RFT parameters
        field_coherence = min(1.0, magnitude / 100.0)  # Coherence factor
        
        # Calculate magnetic phase differential
        component_variance = ((Bx - magnitude/3)**2 + (By - magnitude/3)**2 + (Bz - magnitude/3)**2) / 3
        magnetic_delta_phi = round(math.sqrt(component_variance) / magnitude if magnitude > 0 else 0, 4)
        
        # Enhanced analysis format
        analysis = f"""🧲 Electromagnetic Field Analysis

Field Components:
• Bx: {Bx:.2f} μT
• By: {By:.2f} μT  
• Bz: {Bz:.2f} μT

RFT Parameters:
• Vector Magnitude: {magnitude:.2f} μT
• Ω_obs: {omega_obs}
• Δφ_magnetic: {magnetic_delta_phi}
• Field Coherence: {field_coherence:.3f}

Observer State: {state}
Magnetic RFT Status: ANALYZED"""

        if ENABLE_LOGGING:
            logger.info(f"Magnetic analysis: magnitude={magnitude:.2f}μT, Ω_obs={omega_obs}, state={state}")
        
        return analysis
        
    except Exception as e:
        logger.error(f"Error analyzing magnetic data: {str(e)}")
        return f"🧲 Magnetic analysis failed: {str(e)}"

def get_simple_magnetic_analysis(Bx, By, Bz):
    """
    Simple magnetic analysis format matching the provided style
    """
    try:
        magnitude = (Bx**2 + By**2 + Bz**2)**0.5
        omega_obs = round(magnitude / 50.0, 4)
        state = predict_rft_state(omega_obs)
        
        return f"🧲 Magnetic Vector: {magnitude:.2f} μT\n🔮 Ω_obs = {omega_obs} → {state}"
        
    except Exception as e:
        logger.error(f"Error in simple magnetic analysis: {str(e)}")
        return "🧲 Magnetic analysis error"

def calculate_render_delay(z):
    """
    Enhanced RFT render delay calculation with improved formatting
    
    Args:
        z: Redshift value (must be ≥ 0)
        
    Returns:
        Formatted render delay analysis string
    """
    if z < 0:
        return "❌ Invalid z: must be ≥ 0"
    
    try:
        tau_eff = round(1.38 * math.log(1 + z), 5)
        D_factor = round(z / (1 + z), 5)
        delta_t_distort = round(tau_eff * (1 + z - 1), 5)
        render_score = "MODERATE" if tau_eff < 3 else "HIGH"

        analysis = (f"📡 Cosmological Render Analysis Redshift\n"
                   f"Parameters: • z = {z} • Distance Factor: {D_factor}\n"
                   f"RFT Temporal Analysis: • τ_eff = {tau_eff} s\n"
                   f"• Temporal Distortion: {delta_t_distort} s\n"
                   f"Render Complexity: {render_score} RFT Render Delay Applied ✅")

        if ENABLE_LOGGING:
            logger.info(f"Render delay calculated: z={z}, τ_eff={tau_eff}s")
        
        return analysis
        
    except Exception as e:
        logger.error(f"Error calculating render delay: {str(e)}")
        return f"❌ Render delay analysis error: {str(e)}"

def get_simple_render_delay(z):
    """
    Simple render delay format matching the provided style
    """
    try:
        if z < 0:
            return "❌ Invalid z: must be ≥ 0"
        
        delay = 1.38 * math.log(1 + z)
        tau_eff = round(delay, 5)
        
        return f"🛰 Redshift: z = {z}\n⏳ τ_eff = {tau_eff} s\nRFT Render Delay Applied ✅"
        
    except Exception as e:
        logger.error(f"Error in simple render delay: {str(e)}")
        return "🛰 Render delay error"

def _classify_render_complexity(tau_eff):
    """Classify render complexity based on τ_eff value"""
    if tau_eff < 1.0:
        return "LOW"
    elif tau_eff < 3.0:
        return "MODERATE"
    elif tau_eff < 6.0:
        return "HIGH"
    else:
        return "EXTREME"