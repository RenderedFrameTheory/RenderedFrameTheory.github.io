"""
Utility functions for RFT Omega Bot
Contains formatting, validation, and helper functions
"""

import re
import math
import logging
from typing import Dict, List, Any, Tuple, Optional
from datetime import datetime
import html

logger = logging.getLogger(__name__)

def format_response(response_data: Dict[str, Any], rft_params: Dict[str, float], 
                   processing_time: float) -> str:
    """
    Format the complete RFT response for Telegram output
    
    Args:
        response_data: Generated response data from ResponseGenerator
        rft_params: RFT calculation parameters
        processing_time: Time taken to process the challenge
        
    Returns:
        Formatted markdown string for Telegram
    """
    
    try:
        # Start building the formatted response
        formatted_response = []
        
        # Add header
        if 'header' in response_data:
            formatted_response.append(response_data['header'])
        
        # Add RFT analysis section
        if 'rft_analysis' in response_data:
            formatted_response.append(response_data['rft_analysis'])
        
        # Add interpretation section
        if 'interpretation' in response_data:
            formatted_response.append(response_data['interpretation'])
        
        # Add theoretical implications
        if 'theoretical_implications' in response_data:
            formatted_response.append(response_data['theoretical_implications'])
        
        # Add observer guidance
        if 'observer_guidance' in response_data:
            formatted_response.append(response_data['observer_guidance'])
        
        # Add technical summary (optional, based on length)
        total_length = sum(len(section) for section in formatted_response)
        if total_length < 3000 and 'technical_summary' in response_data:
            formatted_response.append(response_data['technical_summary'])
        
        # Add processing footer
        footer = _generate_processing_footer(processing_time, rft_params)
        formatted_response.append(footer)
        
        # Join all sections
        final_response = '\n\n'.join(formatted_response)
        
        # Ensure response doesn't exceed Telegram limits (4096 chars max)
        if len(final_response) > 4000:
            final_response = _truncate_response(final_response)
        
        # Clean text for plain text sending (no markdown processing needed)
        final_response = _clean_for_plain_text(final_response)
        
        return final_response
        
    except Exception as e:
        logger.error(f"Error formatting response: {str(e)}")
        return _generate_error_response("Response formatting failed", str(e))

def _generate_processing_footer(processing_time: float, rft_params: Dict[str, float]) -> str:
    """Generate processing footer with timing and RFT signature"""
    
    footer = f"""---
⏱️ **Processing Time:** {processing_time:.2f}s
🔬 **RFT Engine:** Ω = {rft_params.get('omega_obs', 0):.3f} × {rft_params.get('chi_liam', 0):.3f} / ({rft_params.get('delta_phi', 1):.3f} × {rft_params.get('upsilon', 1):.3f})
📡 **Observer Sync:** {datetime.now().strftime('%H:%M:%S UTC')}

*RFT Ωmega Bot - Challenge. Name It. It Will Render It.*"""
    
    return footer

def _truncate_response(response: str, max_length: int = 4000) -> str:
    """Truncate response to fit Telegram limits while preserving sections"""
    
    if len(response) <= max_length:
        return response
    
    # Try to truncate at section boundaries
    sections = response.split('\n\n')
    truncated_sections = []
    current_length = 0
    
    for section in sections:
        if current_length + len(section) + 2 <= max_length - 100:  # Leave room for truncation notice
            truncated_sections.append(section)
            current_length += len(section) + 2
        else:
            break
    
    truncated_response = '\n\n'.join(truncated_sections)
    truncated_response += "\n\n⚠️ Response truncated due to length limits. Use /status for detailed metrics."
    
    return truncated_response

def _clean_for_plain_text(text: str) -> str:
    """Clean text for plain text Telegram sending (no markdown)"""
    
    # Remove markdown formatting characters since we're sending as plain text
    text = text.replace('**', '')  # Remove bold markers
    text = text.replace('*', '')   # Remove italic markers
    text = text.replace('`', '')   # Remove code markers
    text = text.replace('_', '')   # Remove underline markers
    
    # Clean up any HTML entities
    text = html.unescape(text)
    
    return text

def _fix_unmatched_markdown(text: str) -> str:
    """Fix unmatched markdown characters"""
    
    # Count markdown characters and fix unmatched ones
    bold_count = text.count('**')
    italic_count = text.count('*') - bold_count * 2
    code_count = text.count('`')
    
    # Fix unmatched bold
    if bold_count % 2 != 0:
        text += '**'
    
    # Fix unmatched italic (single *)
    if italic_count % 2 != 0:
        text += '*'
    
    # Fix unmatched code
    if code_count % 2 != 0:
        text += '`'
    
    return text

def validate_challenge(challenge_text: str) -> Dict[str, Any]:
    """
    Validate challenge input before processing
    
    Args:
        challenge_text: The challenge text to validate
        
    Returns:
        Dictionary with validation results
    """
    
    validation_result = {
        'valid': True,
        'reason': '',
        'warnings': [],
        'normalized_text': challenge_text.strip()
    }
    
    try:
        # Basic length validation
        if not challenge_text or not challenge_text.strip():
            validation_result['valid'] = False
            validation_result['reason'] = "Challenge cannot be empty"
            return validation_result
        
        normalized_text = challenge_text.strip()
        
        # Length limits
        if len(normalized_text) < 10:
            validation_result['valid'] = False
            validation_result['reason'] = "Challenge too short (minimum 10 characters)"
            return validation_result
        
        if len(normalized_text) > 1000:
            validation_result['valid'] = False
            validation_result['reason'] = "Challenge too long (maximum 1000 characters)"
            return validation_result
        
        # Content validation
        if not _contains_meaningful_content(normalized_text):
            validation_result['valid'] = False
            validation_result['reason'] = "Challenge must contain meaningful scientific or conceptual content"
            return validation_result
        
        # Check for spam patterns
        if _is_spam_like(normalized_text):
            validation_result['valid'] = False
            validation_result['reason'] = "Challenge appears to be spam or nonsensical"
            return validation_result
        
        # Check for potentially harmful content
        if _contains_harmful_content(normalized_text):
            validation_result['valid'] = False
            validation_result['reason'] = "Challenge contains inappropriate content"
            return validation_result
        
        # Add warnings for better challenges
        warnings = _generate_challenge_warnings(normalized_text)
        validation_result['warnings'] = warnings
        
        validation_result['normalized_text'] = normalized_text
        
        logger.debug(f"Challenge validation passed: {len(normalized_text)} chars")
        
    except Exception as e:
        logger.error(f"Error validating challenge: {str(e)}")
        validation_result['valid'] = False
        validation_result['reason'] = f"Validation error: {str(e)}"
    
    return validation_result

def _contains_meaningful_content(text: str) -> bool:
    """Check if text contains meaningful scientific/conceptual content"""
    
    # Convert to lowercase for analysis
    text_lower = text.lower()
    
    # Scientific/conceptual keywords that indicate meaningful content
    meaningful_keywords = [
        'how', 'why', 'what', 'when', 'where', 'which',
        'theory', 'principle', 'law', 'equation', 'model',
        'quantum', 'consciousness', 'observer', 'reality', 'time',
        'space', 'energy', 'matter', 'field', 'wave', 'particle',
        'brain', 'mind', 'perception', 'awareness', 'experience',
        'physics', 'science', 'experiment', 'hypothesis', 'test',
        'calculate', 'analyze', 'measure', 'observe', 'render',
        'synchronize', 'align', 'coherence', 'resonance'
    ]
    
    # Check for presence of meaningful keywords
    keyword_count = sum(1 for keyword in meaningful_keywords if keyword in text_lower)
    
    # Check for question patterns
    has_question = '?' in text or any(q_word in text_lower for q_word in ['how', 'why', 'what', 'can', 'does', 'is'])
    
    # Check for sufficient word diversity
    words = text_lower.split()
    unique_words = set(words)
    word_diversity = len(unique_words) / len(words) if words else 0
    
    # Meaningful content criteria
    return (keyword_count >= 1 or has_question) and word_diversity > 0.3

def _is_spam_like(text: str) -> bool:
    """Check if text appears to be spam or nonsensical"""
    
    # Check for excessive repetition
    words = text.lower().split()
    if len(words) > 5:
        word_counts = {}
        for word in words:
            word_counts[word] = word_counts.get(word, 0) + 1
        
        # If any word appears more than 50% of the time, likely spam
        max_word_frequency = max(word_counts.values()) / len(words)
        if max_word_frequency > 0.5:
            return True
    
    # Check for excessive special characters
    special_char_count = sum(1 for char in text if not char.isalnum() and char != ' ')
    if special_char_count > len(text) * 0.3:
        return True
    
    # Check for random character patterns
    if re.search(r'[a-zA-Z]{20,}', text) and not any(word in text.lower() for word in ['consciousness', 'synchronization', 'theoretical']):
        return True
    
    return False

def _contains_harmful_content(text: str) -> bool:
    """Check for potentially harmful or inappropriate content"""
    
    text_lower = text.lower()
    
    # Basic harmful content patterns (can be expanded)
    harmful_patterns = [
        r'\b(hack|crack|exploit|attack|bomb|kill|destroy|harm|hurt|violence|threat)\b',
        r'\b(illegal|criminal|fraud|scam|steal|cheat)\b',
        r'(personal|private|confidential).*(information|data|details)',
        r'\b(password|credit.*card|ssn|social.*security)\b'
    ]
    
    for pattern in harmful_patterns:
        if re.search(pattern, text_lower):
            return True
    
    return False

def _generate_challenge_warnings(text: str) -> List[str]:
    """Generate warnings to help improve challenge quality"""
    
    warnings = []
    text_lower = text.lower()
    
    # Check for very short challenges
    if len(text.split()) < 5:
        warnings.append("Consider providing more context for better RFT analysis")
    
    # Check for lack of question structure
    if '?' not in text and not any(q_word in text_lower for q_word in ['how', 'why', 'what']):
        warnings.append("Phrasing as a question may improve RFT processing")
    
    # Check for vague language
    vague_indicators = ['thing', 'stuff', 'something', 'anything', 'everything']
    if any(indicator in text_lower for indicator in vague_indicators):
        warnings.append("More specific terminology may enhance RFT coherence")
    
    return warnings

def _generate_error_response(error_type: str, error_details: str) -> str:
    """Generate formatted error response"""
    
    error_response = f"""❌ **RFT Processing Error**

**Error Type:** {error_type}

**Details:** {error_details}

**Troubleshooting:**
• Ensure your challenge is clearly formulated
• Try rephrasing with more specific parameters  
• Check that the challenge falls within supported categories

Use `/help` for guidance on proper challenge formatting.

*RFT Ωmega Bot - Challenge. Name It. It Will Render It.*"""
    
    return error_response

def calculate_text_complexity(text: str) -> float:
    """Calculate complexity score for text (0.0 to 1.0)"""
    
    if not text:
        return 0.0
    
    words = text.split()
    sentences = text.split('.')
    
    # Average word length
    avg_word_length = sum(len(word) for word in words) / len(words) if words else 0
    
    # Average sentence length
    avg_sentence_length = len(words) / len(sentences) if sentences else len(words)
    
    # Vocabulary diversity
    unique_words = set(word.lower() for word in words)
    vocabulary_diversity = len(unique_words) / len(words) if words else 0
    
    # Complexity indicators
    complex_word_count = sum(1 for word in words if len(word) > 6)
    complex_word_ratio = complex_word_count / len(words) if words else 0
    
    # Combine metrics
    complexity = (
        min(avg_word_length / 8, 1.0) * 0.25 +
        min(avg_sentence_length / 20, 1.0) * 0.25 +
        vocabulary_diversity * 0.25 +
        complex_word_ratio * 0.25
    )
    
    return max(0.0, min(complexity, 1.0))

def extract_scientific_terms(text: str) -> List[str]:
    """Extract scientific and technical terms from text"""
    
    scientific_patterns = [
        r'\b\w*quantum\w*\b',
        r'\b\w*conscious\w*\b',
        r'\b\w*observe\w*\b',
        r'\b\w*theory\w*\b',
        r'\b\w*principle\w*\b',
        r'\b\w*equation\w*\b',
        r'\b\w*temporal\w*\b',
        r'\b\w*coherence\w*\b',
        r'\b\w*synchron\w*\b',
        r'\b\w*render\w*\b'
    ]
    
    scientific_terms = []
    text_lower = text.lower()
    
    for pattern in scientific_patterns:
        matches = re.findall(pattern, text_lower)
        scientific_terms.extend(matches)
    
    # Remove duplicates and return
    return list(set(scientific_terms))

def format_rft_equation(omega_obs: float, chi_liam: float, delta_phi: float, 
                       upsilon: float, omega_result: float) -> str:
    """Format RFT equation for display"""
    
    equation = f"Ω = ({omega_obs:.4f} × {chi_liam:.4f}) / ({delta_phi:.4f} × {upsilon:.4f}) = {omega_result:.4f}"
    return f"`{equation}`"

def generate_observer_id(user_id: int) -> str:
    """Generate formatted observer ID"""
    return f"OBS_{user_id:08d}"

def calculate_phase_stability(delta_phi: float) -> Tuple[float, str]:
    """Calculate phase stability and description"""
    
    stability = abs(math.cos(delta_phi))
    
    if stability > 0.9:
        description = "Excellent"
    elif stability > 0.7:
        description = "Good"
    elif stability > 0.5:
        description = "Moderate"
    elif stability > 0.3:
        description = "Variable"
    else:
        description = "Unstable"
    
    return stability, description

def format_processing_time(seconds: float) -> str:
    """Format processing time for display"""
    
    if seconds < 1:
        return f"{seconds*1000:.0f}ms"
    elif seconds < 60:
        return f"{seconds:.2f}s"
    else:
        minutes = int(seconds // 60)
        remaining_seconds = seconds % 60
        return f"{minutes}m {remaining_seconds:.1f}s"

def normalize_coherence_value(value: float, base_value: float = 2.718) -> float:
    """Normalize coherence value to 0-1 range"""
    return min(value / (base_value * 2), 1.0)

def get_challenge_category_emoji(challenge_type: str) -> str:
    """Get emoji for challenge category"""
    
    emoji_map = {
        'cognitive': '🧠',
        'theoretical': '📚',
        'quantum': '⚛️',
        'temporal': '⏰',
        'perceptual': '👁️',
        'consciousness': '✨',
        'observer': '🔭',
        'synchronization': '🔄',
        'ai_alignment': '🤖',
        'general': '🔬'
    }
    
    return emoji_map.get(challenge_type, '❓')

def validate_rft_parameters(params: Dict[str, float]) -> Dict[str, Any]:
    """Validate RFT parameters for mathematical consistency"""
    
    validation = {
        'valid': True,
        'warnings': [],
        'errors': []
    }
    
    required_params = ['omega_obs', 'chi_liam', 'delta_phi', 'upsilon']
    
    # Check for required parameters
    for param in required_params:
        if param not in params:
            validation['valid'] = False
            validation['errors'].append(f"Missing required parameter: {param}")
    
    if not validation['valid']:
        return validation
    
    # Validate parameter ranges
    if params['omega_obs'] <= 0:
        validation['warnings'].append("Observer state (Ω_obs) should be positive")
    
    if params['chi_liam'] <= 0:
        validation['warnings'].append("Coherence coefficient (χ_Liam) should be positive")
    
    if params['delta_phi'] <= 0:
        validation['warnings'].append("Phase differential (Δφ) should be positive")
    
    if params['upsilon'] <= 0:
        validation['errors'].append("Temporal scaling (Υ) must be positive to avoid division by zero")
        validation['valid'] = False
    
    # Check for extreme values
    if params['omega_obs'] > 10:
        validation['warnings'].append("Very high observer state may indicate system instability")
    
    if params['chi_liam'] > 20:
        validation['warnings'].append("Extremely high coherence coefficient detected")
    
    return validation

def create_debug_info(data: Dict[str, Any]) -> str:
    """Create formatted debug information"""
    
    debug_lines = []
    
    def format_value(key: str, value: Any, indent: int = 0) -> str:
        indent_str = "  " * indent
        
        if isinstance(value, dict):
            lines = [f"{indent_str}{key}:"]
            for sub_key, sub_value in value.items():
                lines.append(format_value(sub_key, sub_value, indent + 1))
            return "\n".join(lines)
        elif isinstance(value, float):
            return f"{indent_str}{key}: {value:.6f}"
        elif isinstance(value, list):
            return f"{indent_str}{key}: [{len(value)} items]"
        else:
            return f"{indent_str}{key}: {value}"
    
    for key, value in data.items():
        debug_lines.append(format_value(key, value))
    
    return "\n".join(debug_lines)

def safe_format(text: str) -> str:
    """
    Safe formatter for Telegram messages - escapes problematic characters
    and ensures RFT math symbols display correctly
    """
    
    if not text:
        return ""
    
    try:
        # Replace problematic characters
        text = text.replace('_', ' ')
        text = text.replace('`', "'")
        
        # Replace RFT math symbols for plain text
        rft_symbols = {
            'τ_eff': 'tau_eff',
            'Δφ': 'delta_phi', 
            'Ω_obs': 'omega_obs',
            'χ_Liam': 'chi_Liam',
            'Υ': 'upsilon'
        }
        
        for symbol, replacement in rft_symbols.items():
            text = text.replace(symbol, replacement)
        
        # Clean up whitespace
        text = re.sub(r'\s+', ' ', text)
        text = text.strip()
        
        # Truncate if too long
        if len(text) > 4000:
            text = text[:3990] + "... [truncated]"
        
        return text
        
    except Exception as e:
        logger.error(f"Error in safe_format: {str(e)}")
        return str(text)[:4000]
